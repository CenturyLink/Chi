# chi-custom-elements

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
npm run lint:checker
npm run prettier
npm run prettier:checker
```

### Tests

```
npm run build:testing
npm run tests:e2e
```
